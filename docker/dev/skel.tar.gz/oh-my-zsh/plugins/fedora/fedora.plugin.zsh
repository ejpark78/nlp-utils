print -P "%F{yellow}The 'fedora' plugin is deprecated. Use the '%Udnf%u' plugin instead.%f"

source "$ZSH/plugins/dnf/dnf.plugin.zsh"
