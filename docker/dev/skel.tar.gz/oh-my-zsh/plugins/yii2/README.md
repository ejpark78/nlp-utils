# Yii2 autocomplete plugin

* Adds autocomplete commands and subcommands for yii.

## Requirements

Autocomplete works from directory where your `yii` file contains.
